<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("page-block-yeudfpofo1").style.top = "0";
  } else {
    document.getElementById("page-block-yeudfpofo1").style.top = "-70px";
  }
}

</script>