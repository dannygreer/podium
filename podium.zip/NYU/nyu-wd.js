<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("page-block-qml27m3gm6c").style.top = "0";
  } else {
    document.getElementById("page-block-qml27m3gm6c").style.top = "-70px";
  }
}

</script>