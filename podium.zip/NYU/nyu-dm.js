<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("page-block-k5w2t6qc09m").style.top = "0";
  } else {
    document.getElementById("page-block-k5w2t6qc09m").style.top = "-70px";
  }
}

</script>